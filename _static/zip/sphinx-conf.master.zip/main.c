#include "resource.h"
#include <stdio.h>

void write(FILE *);

int main(int argc, char const *argv[]) {
  FILE *output = stdout;
  if (argc < 2) {
    write(output);
  } else {
    for (int i = 1; i < argc; ++i) {
        output = freopen(argv[i], "wb", output);
      if (output != NULL) {
        write(output);
      } else {
          return -1;
      }
    }
  }
  return 0;
};

void write(FILE *stream) {
  for (unsigned int j = 0; j < conf_py_len; ++j) {
    fputc(conf_py[j], stream);
  }
  fclose(stream);
}
