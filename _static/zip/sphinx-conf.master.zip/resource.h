#ifndef _RESOURCE_H
#define _RESOURCE_H

extern unsigned char conf_py[];
extern unsigned int conf_py_len;

#endif /* _RESOURCE_H */
