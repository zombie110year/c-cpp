
生成一个 Sphinx 文档项目的目录结构.

# 手动编辑的文件

1. `resource.c`, `resource.h`
2. `main.c`
3. 两个 `Makefile`

# 资源文件

1. `resource/conf.py`

# 自动生成的文件

1. `resource/build/*`
2. `*.o`, `*.exe`
